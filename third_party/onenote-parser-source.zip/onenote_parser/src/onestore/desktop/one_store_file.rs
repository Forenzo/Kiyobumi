use core::fmt;

use super::file_structure::{
    FileNodeListFragment, FreeChunkListFragment, OneStoreHeader, TransactionLogFragment,
};
use crate::Reader;
use crate::errors::Result;
use crate::fsshttpb::data::cell_id::CellId;
use crate::onestore::desktop::file_structure;
use crate::onestore::desktop::objects;
use crate::onestore::desktop::objects::root_file_node_list::RootFileNodeList;
use crate::onestore::desktop::parse::Parse;
use crate::onestore::desktop::{common::FileChunkReference, file_structure::FileNodeList};
use crate::onestore::{OneStore, OneStoreType};

/// A OneNote file packaged in the standard OneNote 2016 format.
///
/// See [\[MS-ONESTORE\] 1.3.1]
///
/// [\[MS-ONESTORE\] 1.3.1]: https://docs.microsoft.com/en-us/openspecs/office_file_formats/ms-onestore/97edf715-5dec-47bd-8f8d-00e45d3a4862
///
#[allow(dead_code)]
pub(crate) struct RevisionStore {
    pub(crate) header: OneStoreHeader,
    pub(crate) free_chunk_list: Vec<FreeChunkListFragment>,
    pub(crate) transaction_log: Vec<TransactionLogFragment>,
    pub(crate) hashed_chunk_list: Vec<FileNodeListFragment>,
    pub(crate) raw_file_node_list: FileNodeList,
    pub(crate) root_file_node_list: RootFileNodeList,
}

impl fmt::Debug for RevisionStore {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if f.alternate() {
            write!(f, "OneStoreFile({:#?})", self.root_file_node_list)
        } else {
            write!(f, "OneStoreFile({:?})", self.root_file_node_list)
        }
    }
}

impl OneStore for RevisionStore {
    fn get_type(&self) -> Result<OneStoreType> {
        if self.header.file_type == guid!("{7B5C52E4-D88C-4DA7-AEB1-5378D02996D3}") {
            Ok(OneStoreType::Section)
        } else if self.header.file_type == guid!("{43FF2FA1-EFD9-4C76-9EE2-10EA5722765F}") {
            Ok(OneStoreType::TableOfContents)
        } else {
            Err(onestore_parse_error!("Invalid GUID on OneStoreFile").into())
        }
    }

    fn data_root(&self) -> &dyn crate::onestore::ObjectSpace {
        self.root_file_node_list.root_object_space()
    }

    fn object_space(&self, id: CellId) -> Option<&dyn crate::onestore::ObjectSpace> {
        // CellId doesn't seem to map perfectly to the ID representation in the OneNote 2016 format.
        // For now, use the 0th ID in CellId as the object space ID and the 1st as the entity within
        // the space's ID.
        let result = self
            .root_file_node_list
            .object_spaces
            .iter()
            .find(|space| space.id == id.0);
        result.map(|space| space as &dyn crate::onestore::ObjectSpace)
    }
}

impl Parse for RevisionStore {
    fn parse(reader: Reader) -> Result<Self> {
        let header = OneStoreHeader::parse(reader)?;

        let mut free_chunk_list = Vec::new();
        let mut free_chunk_ref = header.fcr_free_chunk_list.clone();
        while !free_chunk_ref.is_fcr_nil() && !free_chunk_ref.is_fcr_zero() {
            let mut reader = free_chunk_ref.resolve_to_reader(reader)?;
            let fragment = FreeChunkListFragment::parse(&mut reader, free_chunk_ref.cb.into())?;
            free_chunk_ref = fragment.fcr_next_chunk.clone();
            free_chunk_list.push(fragment);
        }

        let mut transaction_log = Vec::new();
        let mut transaction_log_ref = header.fcr_transaction_log.clone();
        let mut remaining_transactions = header.c_transactions_in_log;
        let mut visited = std::collections::HashSet::new();
        while remaining_transactions > 0 {
            if transaction_log_ref.is_fcr_nil() || transaction_log_ref.is_fcr_zero()
                || !visited.insert(transaction_log_ref.stp) {
                return Err(onestore_parse_error!("Incomplete or cyclic transaction log").into());
            }
            let mut fragment_reader = transaction_log_ref.resolve_to_reader(reader)?;
            let fragment = TransactionLogFragment::parse_committed(
                &mut fragment_reader, transaction_log_ref.cb as usize, &mut remaining_transactions,
            )?;
            let next = fragment.next_fragment.clone();
            transaction_log.push(fragment);
            if let Some(next) = next { transaction_log_ref = next; }
        }

        let mut parse_context = file_structure::ParseContext::new();
        parse_context.update_from_transaction_log(&transaction_log);

        let mut hashed_chunk_list = Vec::new();
        let mut hash_chunk_ref = header.fcr_hashed_chunk_list.clone();
        while !hash_chunk_ref.is_fcr_nil() && !hash_chunk_ref.is_fcr_zero() {
            let mut reader = hash_chunk_ref.resolve_to_reader(reader)?;
            let fragment = FileNodeListFragment::parse(
                &mut reader,
                &mut parse_context,
                hash_chunk_ref.cb as usize,
            )?;
            hash_chunk_ref = fragment.next_fragment.clone();
            hashed_chunk_list.push(fragment);
        }

        let file_node_list_root = &header.fcr_file_node_list_root;
        let raw_file_node_list =
            if !file_node_list_root.is_fcr_nil() && !file_node_list_root.is_fcr_zero() {
                let mut reader = file_node_list_root.resolve_to_reader(reader)?;
                FileNodeList::parse(
                    &mut reader,
                    &mut parse_context,
                    file_node_list_root.cb as usize,
                )?
            } else {
                FileNodeList::default()
            };
        let parse_context = objects::parse_context::ParseContext::new();
        let root_file_node_list = RootFileNodeList::parse(&raw_file_node_list, &parse_context)?;

        Ok(Self {
            header,
            free_chunk_list,
            transaction_log,
            hashed_chunk_list,
            raw_file_node_list,
            root_file_node_list,
        })
    }
}
