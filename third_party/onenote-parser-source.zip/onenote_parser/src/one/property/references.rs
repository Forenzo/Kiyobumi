use crate::errors::{ErrorKind, Result};
use crate::one::property::PropertyType;
use crate::onestore::Object;
use crate::onestore::shared::property::{PropertyId, PropertyValue};

pub(crate) struct References;

impl References {
    pub(crate) fn get_predecessors(
        prop_type: PropertyType,
        object: &Object,
    ) -> Result<impl Iterator<Item = &PropertyValue>> {
        let prop_index = object
            .props
            .properties()
            .index(PropertyId::new(prop_type as u32))
            .ok_or_else(|| {
                ErrorKind::MalformedOneNoteFileData(
                    format!("no object offset for property {:?}", prop_type).into(),
                )
            })?;

        let predecessors = object
            .props
            .properties()
            .values_with_index()
            .filter(move |(idx, _)| *idx < prop_index)
            .map(|(_, value)| value);

        Ok(predecessors)
    }
}
